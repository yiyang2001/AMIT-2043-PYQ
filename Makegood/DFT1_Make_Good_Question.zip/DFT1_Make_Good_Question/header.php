<header>
    <link rel="stylesheet" type="text/css" href="./css/style.css">

    <h1>Make Good Test</h1>
    <nav>
        <a href="create_student.php">Create Student</a> |
        <a href="view_students.php">View Students</a> |
    </nav>
</header>