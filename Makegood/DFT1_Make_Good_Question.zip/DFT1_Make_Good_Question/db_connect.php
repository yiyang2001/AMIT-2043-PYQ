<?php
$servername = "";
$username = "";
$password = "";
$dbname = "";

// Create connection
// Hint : mysqli_connect()



// Check connection , if connection failed, print error
// Hint : die(), mysqli_connect_error()

?>
